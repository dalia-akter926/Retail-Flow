<!-- <h3 class="bg-dark-subtle px-2 py-2">Category</h3> -->
                    <ul class="list-group p-2 fw-semibold">
                        <li class="list-group-item mb-1">
                            <a class="text-decoration-none " href="add_category.php">Add Category</a>
                        </li>
                        <li class="list-group-item">
                            <a class="text-decoration-none" href="list_of_category.php">Category List</a>
                        </li>
                        
                    </ul>
                    <!-- <h3 class="bg-dark-subtle px-2 py-2">Product</h3> -->
                    <ul class="list-group p-2 fw-semibold">
                        <li class="list-group-item mb-1">
                            <a class="text-decoration-none " href="add_product.php">Add Product</a>
                        </li>
                        <li class="list-group-item">
                            <a class="text-decoration-none" href="list_of_product.php">Product List</a>
                        </li>
                        
                    </ul>
                    <!-- <h3 class="bg-dark-subtle px-2 py-2">Store Product</h3> -->
                    <ul class="list-group p-2 fw-semibold">
                        <li class="list-group-item mb-1">
                            <a class="text-decoration-none " href="add_store_product.php">Add Store Product</a>
                        </li>
                        <li class="list-group-item">
                            <a class="text-decoration-none" href="list_of_entry_product.php">Store Product List</a>
                        </li>
                        
                    </ul>
                    <!-- <h3 class="bg-dark-subtle px-2 py-2">Spend Product</h3> -->
                    <ul class="list-group p-2 fw-semibold">
                        <li class="list-group-item mb-1">
                            <a class="text-decoration-none " href="add_spend_product.php">Add Spend Product</a>
                        </li>
                        <li class="list-group-item">
                            <a class="text-decoration-none" href="list_of_spend_product.php">Spend Product List</a>
                        </li>
                        
                    </ul>
                    <!-- <h3 class="bg-dark-subtle px-2 py-2">User</h3> -->
                    <ul class="list-group p-2 fw-semibold">
                        <li class="list-group-item mb-1">
                            <a class="text-decoration-none " href="add_user.php">Add User</a>
                        </li>
                        <li class="list-group-item">
                            <a class="text-decoration-none" href="list_of_users.php">Users List</a>
                        </li>
                        
                    </ul>
                    <!-- <h3 class="bg-dark-subtle px-2 py-2">Report</h3> -->
                    <ul class="list-group p-2 fw-semibold">
                        <li class="list-group-item mb-1">
                            <a class="text-decoration-none " href="report.php">Generate Report</a>
                        </li>
                        
                    </ul>