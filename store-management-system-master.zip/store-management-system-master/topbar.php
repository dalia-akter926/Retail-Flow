<div class="row my-4 border-bottom border-success">
                <div class="col-sm-9">
                  <a href="index.php"><h3>Store Management System</h3></a> 
                </div>
                <div class="col-sm-3 text-end">
                  <p> <?php echo $user_first_name. ' ' . $user_last_name ?>   <a class="mx-2 text-decoration-none btn btn-secondary" href="logout.php">Logout</a></p>
                </div>
            </div>